
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/"

library(tidyverse)
library(MuMIn)

options(na.action = "na.fail")

# set working directory to root of the package
setwd(root_folder)

#lond data
df_first = read_tsv("./data/RawData/first_spawning_environment_230116.txt")

##Water temp: Average of the values at time1 (9:00) and time3 (16:00) in M4 and S1 tanks
#Effects of the envronmental factors on first spawning date
################################################
#time 0-30: 
################################################
df_first_30 = df_first %>% 
  dplyr::filter(year>=2005) %>% 
  dplyr::filter(time>=1, time<=30, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "first_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>% 
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_first_30 <- glm(first_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, family = gaussian(link = "identity"), data=df_first_30)
a_first_30 <- dredge(l.model_first_30, rank="AIC") #model selection
print(a_first_30)

best_first_30 <- glm(first_spawning ~ as.numeric(norm_SST) +  as.numeric(norm_rain) +  as.numeric(norm_wind), family = gaussian(link = "identity"), data=df_first_30) #best-fit model
summary(best_first_30)
es.model_first_30 = best_first_30 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_first_30)


################################################
#time 31-60:
################################################
df_first_60 = df_first %>%
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=31, time<=60,!is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "first_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>% 
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection by AIC
l.model_first_60 <- glm(first_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, data=df_first_60)
a_first_60 <- dredge(l.model_first_60, rank="AIC") #model selection
print(a_first_60)
best_first_60 <- glm(first_spawning ~ as.numeric(norm_SST) + as.numeric(norm_wind), family = gaussian(link = "identity"), data=df_first_60) #best-fit model
summary(best_first_60)
es.model_first_60 = best_first_60 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_first_60)

################################################
#time 61-90:
################################################
df_first_90 = df_first %>% 
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=61, time<=90, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "first_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%  
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection by AIC
l.model_first_90 <- glm(first_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, data=df_first_90)
a_first_90 <- dredge(l.model_first_90, rank="AIC") #model selection
print(a_first_90)
best_first_90 <- glm(first_spawning ~ as.numeric(norm_SST) + as.numeric(norm_wind) + as.numeric(norm_solar_flux), family = gaussian(link = "identity"), data=df_first_90) #best-fit model
summary(best_first_90)
es.model_first_90 = best_first_90 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_first_90)

################################################
#time 91-120:
################################################
df_first_120 = df_first %>% 
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=91, time<=120, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "first_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%  
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection by AIC
l.model_first_120 <- glm(first_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, data=df_first_120)
a_first_120 <- dredge(l.model_first_120, rank="AIC") #model selection
print(a_first_120)
best_first_120 <- glm(first_spawning ~ as.numeric(norm_deltaSST), family = gaussian(link = "identity"), data=df_first_120) #best-fit model
summary(best_first_120)
es.model_first_120 = best_first_120 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_first_120)

