
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/"

library(tidyverse)
library(MuMIn)

options(na.action = "na.fail")

# set working directory to root of the package
setwd(root_folder)

#load data
df_peak_score = read_tsv("./data/RawData/peak_spawning_environment_230116.txt")

#peak spawning (spawning score)
################################################
#time 0-30:
################################################
df_peakscore_30 = df_peak_score %>% 
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=1, time<=30, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "peak_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%  
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#Model selection by AIC
l.model_peak_score_30 <- glm(peak_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux , data=df_peakscore_30)
a_peakscore_30 <- dredge(l.model_peak_score_30, rank="AIC") #model selection
print(a_peakscore_30)
best_peakscore_30 <- glm(peak_spawning ~ as.numeric(norm_SST) + as.numeric(norm_rain) + as.numeric(norm_solar_flux), data=df_peakscore_30) #best-fit model
summary(best_peakscore_30)
es.model_peakscore_30 = best_peakscore_30 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_peakscore_30)

################################################
#time 31-60: 
################################################
df_peakscore_60 = df_peak_score %>% 
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=31, time<=60, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "peak_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%  
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#Model selection by AIC
l.model_peak_score_60 <- glm(peak_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux , data=df_peakscore_60)
a_peakscore_60 <- dredge(l.model_peak_score_60, rank="AIC") #model selection
print(a_peakscore_60)
best_peakscore_60 <- glm(peak_spawning ~ as.numeric(norm_SST) + as.numeric(norm_wind), data=df_peakscore_60) #best-fit model
summary(best_peakscore_60)
es.model_peakscore_60 = best_peakscore_60 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_peakscore_60)

################################################
#time 61-90:
################################################
df_peakscore_90 = df_peak_score %>% 
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=61, time<=90, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "peak_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%  
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_peak_score_90 <- glm(peak_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux , data=df_peakscore_90)
a_peakscore_90 <- dredge(l.model_peak_score_90, rank="AIC") #model selection
print(a_peakscore_90)
best_peakscore_90 <- glm(peak_spawning ~ as.numeric(norm_solar_flux), data=df_peakscore_90) #best-fit model
summary(best_peakscore_90)
es.model_peakscore_90 = best_peakscore_90 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_peakscore_90)

################################################
#time 91-120:
################################################
df_peakscore_120 = df_peak_score %>% 
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=91, time<=120, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>% 
  dplyr::select(c("year", "peak_spawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%  
  group_by(year) %>% 
  dplyr::summarise_all(mean) %>% 
  dplyr::mutate(norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_SST = scale(SST_M4_S1_mean), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_peak_score_120 <- glm(peak_spawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux , data=df_peakscore_120)
a_peakscore_120 <- dredge(l.model_peak_score_120, rank="AIC") #model selection
print(a_peakscore_120)
best_peakscore_120 <- glm(peak_spawning ~ as.numeric(norm_deltaSST) + as.numeric(norm_rain) + as.numeric(norm_solar_flux), data=df_peakscore_120) #best-fit model
summary(best_peakscore_120)
es.model_peakscore_120 = best_peakscore_120 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_peakscore_120)

