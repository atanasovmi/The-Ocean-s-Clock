
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/"

library(tidyverse)
library(MuMIn)

options(na.action = "na.fail")

# set working directory to root of the package
setwd(root_folder)

#lond data
df_index = read_tsv("./data/RawData/spawning_index_environment_230116.txt") 

#time 0-30
################################################
df_index_30_1 = df_index %>%
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=1, time<=30, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>%
  dplyr::select(c("year", "NoOfSpawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>% 
  group_by(year) %>%
  dplyr::summarise_all(mean) %>%
  dplyr::mutate(norm_SST = scale(SST_M4_S1_mean), norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_var_30_1 <- glm(NoOfSpawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, data=df_index_30_1)
a_var_30_1 <- dredge(l.model_var_30_1, rank="AIC") #model selection
a_var_30_1
best_var_30_1 <- glm(NoOfSpawning ~ norm_wind, data=df_index_30_1) #best-fit model
summary(best_var_30_1)
es.model_var_30_1 = best_var_30_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_var_30_1)

#full model
summary(l.model_var_30_1)
es.model_best_var_30_1 = l.model_var_30_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_best_var_60_1)

################################################
#time 31-60
################################################
df_index_60_1 = df_index %>%
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=31, time<=60, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>%
  dplyr::select(c("year", "NoOfSpawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%
  group_by(year) %>%
  dplyr::summarise_all(mean) %>%
  dplyr::mutate(norm_SST = scale(SST_M4_S1_mean), norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_var_60_1 <- glm(NoOfSpawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux , data=df_index_60_1)
a_var_60_1 <- dredge(l.model_var_60_1, rank="AIC") #model selection
a_var_60_1
#null

#full model
summary(l.model_var_60_1)
es.model_best_var_60_1 = l.model_var_60_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_best_var_60_1)


################################################
#time 61-90
################################################
df_index_90_1 = df_index %>%
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=61, time<=90, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>%
  dplyr::select(c("year", "NoOfSpawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%
  group_by(year) %>%
  dplyr::summarise_all(mean) %>%
  dplyr::mutate(norm_SST = scale(SST_M4_S1_mean), norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_var_90_1 <- glm(NoOfSpawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, data=df_index_90_1)
a_var_90_1 <- dredge(l.model_var_90_1, rank="AIC") #model selection
a_var_90_1
best_var_90_1 <- glm(NoOfSpawning ~ norm_SST, data=df_index_90_1) #best-fit model
summary(best_var_90_1)
es.model_var_90_1 = best_var_90_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_var_90_1)

#full model
summary(l.model_var_90_1)
es.model_var_90_1 = l.model_var_90_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_var_90_1)


################################################
#time 91-120
################################################
df_index_120_1 = df_index %>%
  dplyr::filter(year>=2005) %>%
  dplyr::filter(time>=91, time<=120, !is.na(solar_flux), !is.na(SST_M4_S1_mean), !is.na(deltaSST_M4_S1_mean)) %>%
  dplyr::select(c("year", "NoOfSpawning", "SST_M4_S1_mean", "deltaSST_M4_S1_mean", "rain", "wind", "solar_flux")) %>%
  group_by(year) %>%
  dplyr::summarise_all(mean) %>%
  dplyr::mutate(norm_SST = scale(SST_M4_S1_mean), norm_wind = scale(wind), norm_rain = scale(rain), norm_solar_flux = scale(solar_flux), norm_deltaSST = scale(deltaSST_M4_S1_mean))

#model selection based on AIC
l.model_var_120_1 <- glm(NoOfSpawning ~ norm_SST + norm_deltaSST + norm_rain + norm_wind + norm_solar_flux, data=df_index_120_1)
a_var_120_1 <- dredge(l.model_var_120_1, rank="AIC") #model selection
a_var_120_1
best_var_120_1 <- glm(NoOfSpawning ~ norm_rain, data=df_index_120_1) #best-fit model
summary(best_var_120_1)
es.model_var_120_1 = best_var_120_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_var_120_1)

#full model
summary(l.model_var_120_1)
es.model_var_120_1 = l.model_var_120_1 %>% broom::tidy(effects = "fixed", conf.int = TRUE)
print(es.model_var_120_1)

