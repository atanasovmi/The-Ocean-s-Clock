
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/" # path of root folder

# set working directory to root of the package
setwd(root_folder)

library(openxlsx)
library(data.table)
library(tidyverse)
library(lubridate)

# load spawning records of wild corals
#first download all data from "https://data.ncl.ac.uk/articles/dataset/Coral_Spawning_Database/13082333" and then put the unzipped folder under the "RawData" folder 
spawn_df <- read.xlsx("./data/RawData/13082333/CSD_Tables.xlsx", sheet = 1)

spawn_df <- spawn_df %>% 
  dplyr::mutate(Date = dmy(Date)) %>% 
  dplyr::mutate(year = year(Date), month = month(Date)) %>% 
  dplyr::filter(year >= 2003&year <= 2017, Genus == "Acropora", Latitude > 0) %>%
  dplyr::select("Site", "Latitude", "Longitude", "Genus", "Species", "Date", "year","month") %>% 
  dplyr::group_by(Site) %>% 
  tidyr::nest() %>% 
  dplyr::mutate(year_long = purrr::map(data, ~length(unique(.$year)))) %>% #count how many years the coral spawning is recorded in each site
  dplyr::filter(year_long >= 5) %>% #select sites with ≥ 5 years' spawning records
  tidyr::unnest()

unique(sort(spawn_df$Date))

# write the datatable to a csv file
write.csv(spawn_df, file = "./data/output/wild_corals_spwaning_dates.csv", 
          row.names=FALSE)

#select the first spawning date for each site and each year
first_spawning_date <- spawn_df %>% 
  dplyr::filter(Species == "intermedia"|Species == "microphthalma"|Species == "tenuis") %>%  #pick up data of three species
  dplyr::group_by(Site, year) %>% 
  tidyr::nest() %>%  
  dplyr::mutate(data = purrr::map(data, function(data_i){
    min_date = min(data_i$Date)
    data_i %>% 
      dplyr::filter(data_i$Date == min_date)
  })) %>%  
  tidyr::unnest() %>% 
  dplyr::select(-c(year_long)) %>% 
  as.data.table()

# write the datatable to a csv file
write.csv(first_spawning_date, file = "./data/output/wild_corals_FS.csv", 
          row.names=FALSE)

# load spawning records of Churaumi Aquarium
df_chura_date = read_csv("./data/RawData/Chura_spawning_environment.csv")
df_chura_DAFM = read_csv("./data/RawData/Chura_spawning_data_DAFM.csv")

df_chura_date = df_chura_date %>%
  dplyr::mutate(date = dmy(date)) %>%
  dplyr::mutate(year = year(date), month = month(date), day = day(date)) %>%
  dplyr::mutate(day_of_year = yday(date))

df_chura_DAFM = df_chura_DAFM %>% 
  dplyr::mutate(date = ymd(date)) %>%
  dplyr::mutate(year = year(date), month = month(date), day = day(date)) %>%
  dplyr::mutate(day_of_year = yday(date))

#extract first spawning dates
df_chura_FS = df_chura_date %>% 
  dplyr::filter(spawning_score != 0) %>% 
  dplyr::group_by(year) %>% 
  tidyr::nest() %>%  
  dplyr::mutate(data = purrr::map(data, function(data_i){
    min_date = min(data_i$day_of_year)
    data_i %>% 
      dplyr::filter(data_i$day_of_year == min_date)
  })) %>%  
  tidyr::unnest()

df_chura_FS <- df_chura_FS %>%
  dplyr::select(c(year, month, date))%>%                                  
  dplyr::mutate(site = "Chura_Aq") %>% 
  as.data.table()

#extract peak spawning dates
df_chura_PS = df_chura_date %>% 
  dplyr::filter(spawning_score != 0) %>% 
  dplyr::group_by(year) %>% 
  tidyr::nest() %>%  
  dplyr::mutate(data = purrr::map(data, function(data_i){
    max_spawning = max(data_i$spawning_score)
    data_i %>% 
      dplyr::filter(data_i$spawning_score == max_spawning)
  })) %>%  
  tidyr::unnest()

df_chura_PS <- df_chura_PS %>%
  dplyr::select(c(year, month, date))%>%                                  
  dplyr::mutate(site = "Chura_Aq") %>% 
  as.data.table()

#curate DAFM data
df_chura_DAFM = df_chura_DAFM %>% 
  dplyr::select(c(date, DAFM, year, month)) %>%
  dplyr::mutate(site = "Chura_Aq") %>% 
  as.data.table()

#combine first/peak spawning dates and DAFM data
chura_data_FS <- left_join(df_chura_FS, df_chura_DAFM, by = c("date", "site", "year", "month"))
chura_data_FS <- chura_data_FS %>% 
  mutate("Latitude" = 26.694472, "Longitude" = 127.878133) %>% #add latitude and longitude information to the chura data
  rename(Date = date)

chura_data_PS <- left_join(df_chura_PS, df_chura_DAFM, by = c("date", "site", "year", "month"))
chura_data_PS <- chura_data_PS %>% 
  mutate("Latitude" = 26.694472, "Longitude" = 127.878133) %>% #add latitude and longitude information to the chura data
  rename(Date = date)

# write the datatable to a csv file
write.csv(chura_data_FS, file = "./data/output/chura_data_FS_sum.csv", 
          row.names=FALSE)

write.csv(chura_data_PS, file = "./data/output/chura_data_PS_sum.csv", 
          row.names=FALSE)


