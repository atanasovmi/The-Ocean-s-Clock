#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# version 20231018

import ephem
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from timezonefinder import TimezoneFinder
from zoneinfo import ZoneInfo

def nearest_fullmoon(df):
    '''
    Returns the full moon which is nearest from a given date
    '''

    obj = TimezoneFinder()
    longitude = df["Longitude"]
    latitude = df["Latitude"]
    zone = ZoneInfo(obj.timezone_at(lng=longitude, lat=latitude))

    date = ephem.Date(df["Date"])
    date_Sp = ephem.to_timezone(date, zone)

    date = ephem.previous_full_moon(date)
    date_pre_FM = ephem.to_timezone(date, zone)

    date = ephem.next_full_moon(date)
    date_next_FM = ephem.to_timezone(date, zone)
    
    if ((date_Sp - date_pre_FM) < (date_next_FM - date_Sp)):
      nearest_FM = datetime.fromisoformat(str(date_pre_FM))
    else:
        nearest_FM = datetime.fromisoformat(str(date_next_FM))
    return nearest_FM

def diff_date(df):
  dt1 = datetime.strptime(df["Date"], ('%Y-%m-%d'))
  dt2 = df["full_moon"].strftime('%Y-%m-%d')
  dt2 = datetime.strptime(dt2, ('%Y-%m-%d'))
  diff = dt1 - dt2
  diff = diff.days
  return diff
  
df_FS = pd.read_csv("./data/output/wild_corals_FS.csv", sep=',')
df_FS["full_moon"] = df_FS.apply(nearest_fullmoon, axis = 1)
df_FS["DAFM"] = df_FS.apply(diff_date, axis=1)
  
data_df_FS = pd.DataFrame(df_FS).sort_values(by=["Site", "Date"])
df_FS.to_csv("./data/output/wild_corals_FS_DAFM.csv",index=False,sep=",")

df_chura_FS = pd.read_csv("./data/output/chura_data_FS_sum.csv", sep=',')
df_chura_FS["full_moon"] = df_chura_FS.apply(nearest_fullmoon, axis = 1)
df_chura_FS["DAFM"] = df_chura_FS.apply(diff_date, axis=1)
  
data_df_chura_FS = pd.DataFrame(df_chura_FS).sort_values(by=["Date"])
df_chura_FS.to_csv("./data/output/chura_data_FS_DAFM.csv",index=False,sep=",")

df_chura_PS = pd.read_csv("./data/output/chura_data_PS_sum.csv", sep=',')
df_chura_PS["full_moon"] = df_chura_PS.apply(nearest_fullmoon, axis = 1)
df_chura_PS["DAFM"] = df_chura_PS.apply(diff_date, axis=1)
  
data_df_chura_PS = pd.DataFrame(df_chura_PS).sort_values(by=["Date"])
df_chura_PS.to_csv("./data/output/chura_data_PS_DAFM.csv",index=False,sep=",")

