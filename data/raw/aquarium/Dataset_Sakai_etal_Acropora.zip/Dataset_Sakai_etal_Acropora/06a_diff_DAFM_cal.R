
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/"

# set working directory to root of the package
setwd(root_folder)

library(data.table)
library(tidyverse)
library(lubridate)

source("./function/diff_date.R")

df_wild = read_csv("./data/output/wild_corals_FS_DAFM.csv")
df_chura_FS = read_csv("./data/output/chura_data_FS_DAFM.csv")
df_chura_PS = read_csv("./data/output/chura_data_PS_DAFM.csv")

df_wild = df_wild %>%
  dplyr::mutate(Date = ymd(Date), full_moon = ymd_hms(full_moon)) %>%
  dplyr::mutate(year = year(Date), month_wild_FM = month(full_moon))

df_wild = df_wild %>% 
  dplyr::select(c(Site, year, month_wild_FM, Date, full_moon, DAFM)) %>%
  as.data.table()

#combined data: first spawning date of wild corals and "first" spawning date of churaumi aquarium corals 
df_chura_FS = df_chura_FS %>% 
  dplyr::mutate(full_moon = ymd_hms(full_moon)) %>%
  dplyr::mutate(month_FM = month(full_moon)) %>%
  dplyr::select(c(year, month_FM, Date, full_moon, DAFM)) %>%
  dplyr::rename(chura_date = Date, chura_FM = full_moon, chura_DAFM = DAFM, month_chura_FM = month_FM) %>% 
  as.data.table()

df_comp_wild_chura_FS <- left_join(df_wild, df_chura_FS, by = c("year"))

df_comp_wild_chura_FS = df_comp_wild_chura_FS %>% 
  dplyr::rowwise() %>% ##create row-wise data frame to apply function to values in each row
  dplyr::mutate(diff_FS_dates = diff_date(Date, chura_date)) ##calculate differences in DAFMs of first/first spawning dates between wild and aquarium populations

df_comp_wild_chura_FS = df_comp_wild_chura_FS %>% 
  dplyr::group_by(Site, year) %>% 
  dplyr::summarise_all(mean)

write.csv(df_comp_wild_chura_FS, file = "./data/output/res01_diff_DAFM_wild_chura_FS.csv", 
          row.names=FALSE)

#combined data: first spawning date of wild corals and "peak" spawning date of churaumi aquarium corals 
df_chura_PS = df_chura_PS %>% 
  dplyr::mutate(full_moon = ymd_hms(full_moon)) %>%
  dplyr::mutate(month_FM = month(full_moon)) %>%
  dplyr::select(c(year, month_FM, Date, full_moon, DAFM)) %>%
  dplyr::rename(chura_date = Date, chura_FM = full_moon, chura_DAFM = DAFM, month_chura_FM = month_FM) %>% 
  as.data.table()

df_comp_wild_chura_PS <- left_join(df_wild, df_chura_PS, by = c("year"))

df_comp_wild_chura_PS = df_comp_wild_chura_PS %>% 
  dplyr::rowwise() %>% ##create row-wise data frame to apply function to values in each row
  dplyr::mutate(diff_PS_dates = diff_date(Date, chura_date)) ##calculate differences in DAFMs of first/peak spawning dates between wild and aquarium populations

df_comp_wild_chura_PS = df_comp_wild_chura_PS %>% 
  dplyr::group_by(Site, year) %>% 
  dplyr::summarise_all(mean)

write.csv(df_comp_wild_chura_PS, file = "./data/output/res02_diff_DAFM_wild_chura_PS.csv", 
          row.names=FALSE)

