
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/"

library(data.table)
library(tidyverse)
library(lubridate)

# set working directory to root of the package
setwd(root_folder)

source("./function/diff_date.R")

df_wild = read_csv("./data/output/wild_corals_spwaning_dates.csv")
df_chura = read_csv("./data/RawData/Chura_spawning_environment.csv")

df_chura = df_chura %>%
  dplyr::mutate(date = dmy(date)) %>%
  dplyr::mutate(year = year(date), month = month(date)) %>% 
  dplyr::mutate(Date = date) %>% 
  dplyr::select(c("spawning_score", "year", "month", "Date"))

df_wild = df_wild %>% 
  dplyr::filter(Species == "intermedia"|Species == "microphthalma"|Species == "tenuis")

df_comp_wild_chura <- left_join(df_wild, df_chura, by = c("Date", "year", "month"))
df_comp_wild_chura <- df_comp_wild_chura %>% 
  dplyr::group_by(Site) %>% 
  dplyr::distinct(Date, .keep_all = TRUE) %>% 
  dplyr::select(c("Site", "Date", "year", "month", "spawning_score"))

df_spawning_match <- df_comp_wild_chura %>% 
  dplyr::group_by(Site) %>% 
  tidyr::nest() %>% 
  dplyr::mutate(data = purrr::map(data, function(data_i){
    total_dates = length(data_i$Date)
    data_i2 = data_i %>% dplyr::filter(spawning_score != 0)
    match_dates = length(data_i2$Date)
    data_i %>% 
      dplyr::mutate(match = match_dates/total_dates)
  })) %>%  
  tidyr::unnest()

write.csv(df_spawning_match, file = "./data/output/res03_spawning_match.csv", 
          row.names=FALSE)
