
#figure
rm(list=ls(all=TRUE)) # clean work space, common practice                                               

root_folder <- "~/Dropbox/Spawning_analysis_2021/analysis/data/"

library(tidyverse)
library(ggbeeswarm)

# set working directory to root of the package
setwd(root_folder)

df_res01_FS = read_csv("./output/res01_diff_DAFM_wild_chura_FS.csv")
df_res02_PS = read_csv("./output/res02_diff_DAFM_wild_chura_PS.csv")
df_res03_match = read_csv("./output/res03_spawning_match.csv")

plot_res01_FS <- df_res01_FS %>%
  dplyr::mutate(Site = gsub(Site, pattern="Cabarruyan_Island", replacement = "Cabarruyan Is.", ignore.case = TRUE)) %>% 
  dplyr::mutate(distance = ifelse(Site == "Sesoko", 8,
                                  ifelse(Site == "Akajima", 81,
                                                ifelse(Site == "Lyudao", 787, 1413))))

plot_res01_FS <- transform(plot_res01_FS, Site = factor(Site, levels=c("Sesoko", "Akajima", "Lyudao", "Cabarruyan Is."))) 

plot_res01_FS <- plot_res01_FS %>% 
  dplyr::mutate(index = "First spawning") %>%
  dplyr::rename(diff_dates = diff_FS_dates) %>% 
  dplyr::select(c("Site", "year", "diff_dates", "distance", "index"))

plot_res02_PS <- df_res02_PS %>%
  dplyr::mutate(Site = gsub(Site, pattern="Cabarruyan_Island", replacement = "Cabarruyan Is.", ignore.case = TRUE)) %>% 
  dplyr::mutate(distance = ifelse(Site == "Sesoko", 8,
                                  ifelse(Site == "Akajima", 81,
                                         ifelse(Site == "Lyudao", 787, 1413))))

plot_res02_PS <- transform(plot_res02_PS, Site = factor(Site, levels=c("Sesoko", "Akajima", "Lyudao", "Cabarruyan Is.")))
plot_res02_PS <- plot_res02_PS %>% 
  dplyr::mutate(index = "Peak spawning") %>% 
  dplyr::rename(diff_dates = diff_PS_dates) %>% 
  dplyr::select(c("Site", "year", "diff_dates", "distance", "index"))

plot_all <- rbind(plot_res01_FS, plot_res02_PS)

# font size to use for text in figure
font_sizes <- data.frame("strip_text" = 12,
                         "legend_title" = 12,
                         "subtitle" = 8,
                         "axis_title" = 12, "axis_text" = 8,
                         "legend_text" = 8)

figure_diff_dates <- ggplot(data = plot_all, aes(x = Site, y = diff_dates, colour = index)) +
  geom_boxplot() +
  geom_quasirandom(dodge.width=0.8, alpha = 0.5) +
  geom_hline(yintercept=0,linetype=2,color='black') +
  theme_bw() + 
  xlab("Reef sites") +
  ylab("Difference (day)") +
  labs(colour = "") +
  scale_colour_manual(values = c("#31A1AA", "#FCAE1E")) +
  scale_x_discrete(labels=c("Sesoko\n(8 km)", "Akajima\n(81 km)", "Lyudao\n(787 km)", "Cabarruyan Is.\n(1413 km)")) +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.title = element_text(hjust = 0, size = font_sizes$legend_title,
                                  margin = margin(0,0,5,0),
                                  face = "bold"),
        plot.subtitle = element_text(hjust = 0, size = font_sizes$subtitle),
        strip.text = element_text(size = font_sizes$strip_text,
                                  margin = margin(0,0,20,0),),
        axis.title.x = element_text(size = font_sizes$axis_title,
                                    margin = margin(8,0,0.0)),
        axis.title.y = element_text(size = font_sizes$axis_title,
                                    margin = margin(0,8,0.0)),
        axis.text = element_text(size = font_sizes$axis_text),
        legend.text = element_text(size = font_sizes$legend_text),
        legend.position = "top",
        legend.justification = "right",
        legend.background = element_rect(fill = "transparent"),
        strip.background = element_rect(fill="darkgrey"),
        plot.margin = unit(c(0.1, 0.1, 0.1, 0.25), "cm"))
plot(figure_diff_dates)

ggsave("../figures/figure_diff_dates.pdf", plot = figure_diff_dates, device = NULL, path = NULL,
        scale = 1,  width = 5, height = 5, dpi = 600, limitsize = TRUE)


plot_res03_match <- df_res03_match %>%
  dplyr::group_by(Site) %>%
  dplyr::summarise_all(mean)

plot_res03_match <- plot_res03_match %>% 
  dplyr::mutate(Site = gsub(Site, pattern="Cabarruyan Island", replacement = "Cabarruyan Is.", ignore.case = TRUE))

plot_res03_match <- transform(plot_res03_match, Site = factor(Site, levels=c("Sesoko", "Akajima", "Lyudao", "Cabarruyan Is.")))

plot_res03 <- data.frame(
  Site   = c("Sesoko", "Sesoko", "Akajima", "Akajima", "Lyudao", "Lyudao", "Cabarruyan Is.", "Cabarruyan Is."),
  sample = c("Matched", "Not Matched", "Matched", "Not Matched", "Matched", "Not Matched", "Matched", "Not Matched"),
  value = c(22, 35-22, 
            9, 12-9, 
            0, 5-0,
            0, 11-0),
  distance = c(8, 8, 81, 81, 787, 787, 1413, 1413)
)

plot_res03 <- plot_res03 %>% 
  dplyr::group_by(Site) %>% 
  tidyr::nest() %>% 
  dplyr::mutate(data, purrr::map(data, function(data_i) {
    label_y = (cumsum(data_i$value) - 0.5 * data_i$value)/ sum(data_i$value)
    data_i %>% 
      dplyr::mutate(label_y = label_y)
  })) %>% 
  tidyr::unnest()

plot_res03$sample2 <- factor(plot_res03$sample, levels = c("Not Matched", "Matched"))

figure_match <- ggplot(data = plot_res03, aes(x = reorder(x = Site, X = distance, FUN = mean))) +
  geom_bar(aes(y = value, fill = sample2), stat ="identity", position = "fill") +
  geom_text(aes(y = label_y, label = value))+
  theme_bw() + 
  xlab("Reef sites") +
  ylab("Spawning coincidence (%)") +
  labs(fill = "") +
  scale_x_discrete(labels=c("Sesoko\n(8 km)", "Akajima\n(81 km)", "Lyudao\n(787 km)","Cabarruyan Is.\n(1413 km)")) +
  scale_y_continuous(labels = scales::percent) +
  scale_fill_manual(values = c("#D3D3D3", "#31A1AA")) +
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.title = element_text(hjust = 0, size = font_sizes$legend_title, 
                                  margin = margin(0,0,5,0),
                                  face = "bold"),
        strip.text = element_text(size = font_sizes$strip_text),
        axis.title.x = element_text(size = font_sizes$axis_title,
                                    margin = margin(8,0,0.0)),
        axis.title.y = element_text(size = font_sizes$axis_title,
                                    margin = margin(0,8,0.0)),
        axis.text = element_text(size = font_sizes$axis_text),
        legend.text = element_text(size = font_sizes$legend_text),
        legend.position = "top",
        legend.justification="right",
        strip.background = element_rect(fill="darkgrey"),
        plot.margin = unit(c(0.1, 0.1, 0.1, 0.25), "cm")) +
  guides(fill = guide_legend(reverse = TRUE))
plot(figure_match)  

ggsave("../figures/figure_match.pdf", plot = figure_match, device = NULL, path = NULL,
       scale = 1,  width = 8, height = 5, dpi = 600, limitsize = TRUE)

#histogram of spawning dates in the churaumi aquarium population
df_spawn = read_csv("./data/RawData/Chura_spawning_data_DAFM.csv")

df_spawn = df_spawn %>% 
  dplyr::mutate(date = ymd(date)) %>%
  dplyr::mutate(year = year(date), month = month(date), day = day(date)) %>%
  dplyr::mutate(day_of_year = yday(date))

d_spawning_day <- df_spawn %>% 
  dplyr::filter(spawning_binary != 0)
p <- ggplot(d_spawning_day,aes(x=DAFM)) + geom_histogram(binwidth=1, fill="#31A1AA", color="#e9ecef", alpha=0.9) + facet_wrap(~norm_month)
p <- p + xlab("Days before and after full moon") + ylab("Number of spawning") + theme(axis.text.x = element_text(size = 15), axis.text.y = element_text(size = 15), axis.title.x = element_text(size = 20), axis.title.y = element_text(size = 20), strip.text = element_text(size = 15))
print(p)

ggsave("./figures/DAFM_histogram.pdf", plot = p, device = NULL, path = NULL,
       scale = 1,  width = 16, height = 10, dpi = 300, limitsize = TRUE)

