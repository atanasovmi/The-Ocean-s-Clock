# load packages
library(lubridate)

# the actual function
diff_date <- function(date1, date2){
    difference = as.numeric(difftime(date(date1), date(date2)))
  return(difference)
}